package com.bal.m.eticaret;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ETicaretApplicationTests {

	@Test
	void contextLoads() {
	}

}
