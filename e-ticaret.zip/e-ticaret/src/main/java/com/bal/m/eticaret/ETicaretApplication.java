package com.bal.m.eticaret;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ETicaretApplication {

	public static void main(String[] args) {
		SpringApplication.run(ETicaretApplication.class, args);
	}

}
